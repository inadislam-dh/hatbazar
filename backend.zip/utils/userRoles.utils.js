module.exports = {
    Admin: 'Admin',
    Manager: 'Manager',
    Employee: "Employee"
}